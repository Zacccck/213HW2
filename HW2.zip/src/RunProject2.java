/**
 * RunProject2 Class is the driver class for PayrollProcessing.
 *
 * @author Yuan zhao,Alexander Galvan
 */
public class RunProject2 {

    public static void main(String[] args) {
        new PayrollProcessing().run();
    }
}

